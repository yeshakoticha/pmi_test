import React, { useEffect, useState } from "react";
import DisplayGrid from "../components/displayGrid";
import InputField from "../components/InputField";
import { Car } from "../model";

const Cars: React.FC = () => {
    const [data, setData] = useState<Car[]>([]);
    const [column, setColumn] = useState<string>('Color');
    const [clear, setClear] = useState<boolean>(false);
    const [filter, setFilter] = useState<string>('');
    
    const gridHeaders = [
        {colKey:'id', headerName: 'ID'},
        {colKey:'name', headerName: 'Name'},
        {colKey:'color', headerName: 'Color'},
    ];

    useEffect(() => {
        fetchAPI();
    },[clear]);

    const fetchAPI = async () : Promise<void> => {
        try{
            const apiResult = await fetch('https://mocki.io/v1/f230fea3-87c3-469d-ac2c-e1bfed24d74c');
            const response = await apiResult.json();
            setData(response);
        }catch(e: unknown){
            if(e instanceof Error){
                throw e.message;
            } 
        }
    }

    const filterRecords = (filterText: string): void => {
        if(filterText===''){
            handleClear()
        }

        let filterColumn = column.toLowerCase();
        setFilter(filterText);
        let filteredData = data.filter((item: Car) => item[filterColumn]?.toLowerCase().includes(filterText.toLowerCase()));
        if(typeof filteredData==='object'){
            setData(filteredData);
        }
    }

    const handleClear = () : void => {
        // SHOULD IDEALLY USE A useReducer hook here.
        setClear(!clear);
        setFilter('');
        setColumn('Color');
    }

    return (
        <>
            <select name="field" onChange={(e) => setColumn(e.target.value)} value={column}>
                {gridHeaders.map((header) => <option value={header.headerName} key={header.colKey}>{header.headerName}</option>)}
            </select>

            <InputField handleFilter={filterRecords} filter={filter} />
            <button onClick={()=>handleClear()}>Clear</button>
            <DisplayGrid data={data} headers={gridHeaders}/>
        </>
        
    )
}

export default Cars;